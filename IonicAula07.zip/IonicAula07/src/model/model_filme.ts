/**
 *  
 *  Claudemir cardoso RA: 816155452
 */

export interface Filme {
    nome: string;
    descricao: string;
}

export interface Genero {
    nome: string;
    genero: string;
}